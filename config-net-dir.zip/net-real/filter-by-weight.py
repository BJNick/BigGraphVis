# This program filters a list of nodes by weight.
# It reads the nodes from file and writes the nodes with weight greater than the given weight to a new file.
# The data is separated by spaces in the format: "from to weight"

weight_threshold = 3

input_filename = "net-real/cross-parker-1.net"
output_filename = "net-real/cross-parker-1-w" + str(weight_threshold) + ".txt"

def filter_by_weight(input_filename, output_filename, weight_threshold):
    with open(input_filename, "r") as input_file:
        with open(output_filename, "w") as output_file:
            for line in input_file:
                line = line.strip()
                line_list = line.split()
                if len(line_list) == 3:
                    if int(line_list[2]) >= weight_threshold:
                        # Write only the from and to but not the weight
                        output_file.write(line_list[0] + " " + line_list[1] + "\n")


filter_by_weight(input_filename, output_filename, weight_threshold)



