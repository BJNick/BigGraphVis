# Takes in two files: a csv file with the node coordinates and a net file with the edges and node labels.
# Outputs a net file with the edges and node labels and the coordinates all in one file.

net_filepath = "net-real/pajek-geom.net"
csv_filepath = "output/pajek-geom.txt_3000.csv"

output_filepath = "output/pajek-geom-with-coords.net"


def sort_file_lines(filepath):
    with open(filepath, "r") as file:
        lines = file.readlines()
        lines.sort(key = lambda x: int(x.split(",")[0].strip()))
        with open(filepath, "w") as file:
            for line in lines:
                file.write(line)
 

def get_coordinate_map(csv_filepath):
    coordinate_map = {}
    with open(csv_filepath, "r") as csv_file:
        for line in csv_file:
            id = int(line.split(",")[0].strip())
            x = line.split(",")[1].strip()
            y = line.split(",")[2].strip()
            coordinate_map[id] = (x, y)
    return coordinate_map 


def csv_to_net(csv_filepath, net_filepath, output_filepath):
    sort_file_lines(csv_filepath)
    # Open the csv file
    with open(csv_filepath, "r") as csv_file:
        # Open the net file
        with open(net_filepath, "r") as net_file:
            # Open the output file
            with open(output_filepath, "w") as output_file:
                mode = ""
                coordinate_map = get_coordinate_map(csv_filepath)
                for line in net_file:
                    # If line starts with *, write it to the output file
                    if line.startswith("*"):
                        mode = line.strip().split(" ")[0]
                        output_file.write(line)
                        continue
                    if (mode == "*Vertices"):
                        # Split the line into its counterparts. The format is as follows:
                        #      1 "S. Kambhampati"                         0.0000    0.0000    0.5000
                        id = int(line.split('"')[0].strip())
                        label = line.split('"')[1].strip()
                        label = '"' + label + '"'
                        x = line.split('"')[2].strip().split()[0].strip()
                        y = line.split('"')[2].strip().split()[1].strip()
                        z = line.split('"')[2].strip().split()[2].strip()
                        # Read new coordinates from the csv file
                        if (id in coordinate_map):
                            x = coordinate_map[id][0]
                            y = coordinate_map[id][1]
                            print(str(id).ljust(5), label.ljust(30), x.ljust(10), y.ljust(10), z, sep='\t', file=output_file)
                    else:
                        output_file.write(line)    


csv_to_net(csv_filepath, net_filepath, output_filepath)
