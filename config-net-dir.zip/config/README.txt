#### How to run the program using command line arguments: ####

# To run the program using the old command line arguments, you must use the following syntax:

# ./graph_viewer gpu|cpu max_iterations num_snaps sg|wg scale gravity exact|approximate edgelist_path out_path png|csv|bin image_w image_h degree_threshold rounds heuristic
# Ex: ./graph_viewer gpu 500 1 sg 80 1 approximate ~/net/web-BerkStan.txt  ~/output png 1024 1024 11 5 6500 

# Note that many of the parameters are not available in the old command line argument format.
# There are just too many parameters to use them all as command line arguments, so use configuration files instead.

#### How to run the program using configuration files: ####

# ./graph_viewer -c [config_file1 config_file2 ...]
# Ex: ./graph_viewer -c ../../../config/README.txt
# Ex: ./graph_viewer -c tree m-polar rand1

# The files will be read in order, and the parameters will be overwritten
# if they are specified in more than one file, last files listed having priority.

# It is recommended to split the configuration files into multiple files, and use 
# inheritance to specify the parameters that are common to all the files.

# Note that this README file is a properly formatted configuration file, and can be used as a template.
# Recommended templates are "template-input.txt", "template-magnet.txt" and "template-poles.txt".

# You may enter a full path "~/config_file.txt" or just the name "config_file". 
# Extension will be assumed to be ".txt" if not specified.
# Default configuration folder is "../../../config/" relative from the "gpu2/builds/linux" folder.
# This could be changed by setting the parameter "config_folder" to the desired path.

# You must not include spaces in configuration files apart from comments: lines starting with "#".
# The parameters and values are case sensitive. Example: "max_iterations=1000"

#### Complete list of config parameters ####

# ForceAtlas2 parameters:
#    "program_call", "cuda_requested", "max_iterations", "num_screenshots", "strong_gravity", "scale", "gravity", "approximate",
#    "in_path", "out_path", "out_format", "image_w", "image_h", "degree_threshold", "rounds", "huenumber",
# Configuration file parameters:
#    "config_folder", "config_chain", "chain_output_name", "chain_separator", "include_timestamp",
# Extra parameters:
#    "community_detection", "attraction_exponent", "attraction", "random_seed", "pin_2_roots", "repulsion_d_squared",
#    "stop_on_divergence", "divergence_factor", "divergence_threshold", 
# Pole parameters:
#    "use_distance_based_edge_direction", "magnetic_pole_separation", "draw_common_edges",
#    "max_influence_distance", "pin_poles", "extra_pole_attraction", "use_pole_segmentation", "pole_list",
# Magnetic field parameters:
#    "use_magnetic_field", "field_type", "bi_directional", "field_strength", "magnetic_constant", "magnetic_alpha", "magnetic_beta",
# Cosmetic parameters:
#    "node_alpha", "edge_alpha", "square_coordinates", "draw_arrows", "min_arrow_length",

# *Note that program_call and config_chain are internal parameters, and should not be specified in configuration files.

#### FORCE ATLAS DEFAULT VALUES ####

# Choose which device to use for running the program, gpu or cpu
cuda_requested=gpu

# Maximum number of iterations to run the algorithm
max_iterations=500

# Number of screenshots to take of the graph in total
num_screenshots=1

# Whether to use the strong gravity mode or not
strong_gravity=sg

# Scale of the graph, also known as the coefficient of the REPULSION FORCE
scale=80

# Gravity multiplier 
gravity=1

# Whether to use the approximate Barners Hut algorithm for repulsion or not
approximate=approximate

# Path to the input file (~ cannot be used here for system home directory)
in_path=../../../net/web-BerkStan.txt

# Path to the output folder (~ cannot be used here for system home directory)
out_path=../../../output/

# Output format of the file, either png, csv, bin or net
out_format=png

# Width and height of the image
image_w=1024
image_h=1024

#### SCoDA COMMUNITY DETECTION ####

# Toggles the use of community detection, SCoDA or none
community_detection=SCoDA

# Threshold for the degree for SCoDA community detection algorithm
degree_threshold=11

# Number of rounds to run the SCoDA algorithm
rounds=5

# Heuristic number for the SCoDA algorithm
huenumber=6500

#### CONFIGURATION FILE PARAMETERS ####

# Path to the configurations folder which will be used to find the configuration files
# Note that ~ cannot be used here for system home directory.
config_folder=../../../config/

# Whether to name the output files after the configuration file chain or not
# Example output filename: "tree screenshots hi-res 1000.png"
chain_output_name=false

# Separator of keys in the output name (default is space)
# chain_separator= 

# Whether to include the timestamp in the output filename or not
# Example output filename: "tree screenshots hi-res 1234124090124_1000.png"
include_timestamp=true

#### EXTRA SIMULATION PARAMETERS ####

# Toggles the use of community detection, SCoDA or none
community_detection=SCoDA

# Attraction exponent for the force atlas 2 algorithm
attraction_exponent=1

# Attraction multiplier for the force atlas 2 algorithm
attraction=1

# Random seed for the force atlas 2 algorithm (default is 1234)
random_seed=1234

# Whether to pin TWO root nodes to the same position in the layout (deprecated, use pin_poles instead)
pin_2_roots=false

# Whether to use a different mode of repulsion force for the force atlas 2 algorithm
# This drastically changes the layout, and can be useful for many graphs (but default is false)
repulsion_d_squared=false

# Whether to stop the algorithm when the graph is not moving anymore
# This can be useful for unstable graphs, but default is false
stop_on_divergence=false

# This is a factor for the divergence threshold, which is the maximum spike between two iterations
# The higher the less likely the algorithm will stop
divergence_factor=1.75

# This is the minimum force that is considered as a divergence and stops the algorithm
divergence_threshold=1e+8

#### POLE PINNING ####

# The list of pole id's to focus on, pin and color code
# Example: 12,45,352
pole_list=

# Whether to pin poles around a circle in the layout
pin_poles=false

# Whether to use the distance based edge direction for undirected graphs
use_distance_based_edge_direction=false

# Maximum hop distance for the influence of poles, -1 means no limit
max_influence_distance=-1

# Extra attraction multiplier for the poles
extra_pole_attraction=1

# Whether to use the pole segmentation BFS algorithm and adjust the attraction with it
use_pole_segmentation=false

# The desired separation between the poles (10000 is usually too much, pick 500 to start with)
magnetic_pole_separation=10000

# Whether to draw edges common to two or more poles or not
draw_common_edges=true

#### MAGNETIC FORCE PARAMETERS ####

# Whether to use the magnetic force to adjust edge orientations or not
use_magnetic_field=false

# The type of magnetic field to use: 
# none, linear/parallel, polar, polar-reversed, concentric, dipole-1, dipole-2, negative-charges
# (choose negative-charges for pole separation)
field_type=linear

# Whether to align the edges in both directions or not, as if they are all undirected
bi_directional=false

# The strength of the magnetic field
field_strength=16

# Additional constant (acts as a multiplier) for the magnetic field
magnetic_constant=1

# The power of the distance in the magnetic equation (dist^alpha)
magnetic_alpha=1

# The power of the angle in the magnetic equation (angle^beta)
magnetic_beta=1

#### COSMETIC PARAMETERS ####

# The color alpha value for the nodes (recommended: 1.0)
node_alpha=0.8

# The color alpha value for the edges (recommended: 0.5)
edge_alpha=0.005

# Whether to use a square coordinate system or not, meaning
# that angles are preserved in the layout and x, y axes
# have the same unit length
square_coordinates=false

# Whether to draw arrows on directed edges or not
draw_arrows=false

# The minimum length of the edge to put an arrow on it
# (the lenngth of an arrow is about 7 pixels)
min_arrow_length=50

