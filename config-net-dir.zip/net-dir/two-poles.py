# Generates two connected balanced trees, 
# BOTH going in the negative direction

subtree_children = 5
nodes = 1000
filename = "net-dir/two-pole" + str(nodes) + ".txt"


with open(filename, "w") as f:
    # Write pairs of nodes representing edges to the file
    nodes_per_side = nodes // 2
    queue1 = [nodes_per_side]
    new_index = nodes_per_side - 1

    # Inward facing tree
    while len(queue1) > 0:
        node = queue1.pop(0)

        for i in range(subtree_children):
            f.write(str(new_index) + " " + str(node) + "\n")
            queue1.append(new_index)
            new_index -= 1  
            if new_index <= 0:
                break
        if new_index <= 0:
            break
    
    # Separate tree
    queue2 = [nodes]
    new_index = nodes - 1

    while len(queue2) > 0:
        node = queue2.pop(0)

        for i in range(subtree_children):
            f.write(str(new_index) + " " + str(node) + "\n")
            queue2.append(new_index)
            new_index -= 1
            if new_index <= nodes_per_side:
                break
        if new_index <= nodes_per_side:
            break

    
    # Connect the remaining nodes in the two queues
    while len(queue1) > 0 and len(queue2) > 0:
        node1 = queue1.pop(0)
        node2 = queue2.pop(0)
        f.write(str(node1) + " " + str(node2) + "\n")
    