# Generates a random acyclic graph

import random
random.seed(1)

nodes = 1000
min_connections = 1
max_connections = 3
jump_length = nodes/2

filename = "net-dir/acyclic" + str(nodes) + ".txt"


with open(filename, "w") as f:
    # Write pairs of nodes representing edges to the file
    for i in range(1, nodes):
        connections = random.randint(min_connections, max_connections)
        # Only close nearby
        for j in range(connections):
            jump_to = random.randint(i+1, i+1+jump_length)
            if (jump_to <= nodes):
                f.write(str(i) + " " + str(jump_to) + "\n")
            #else:
                #f.write(str(i) + " " + str(nodes) + "\n")








