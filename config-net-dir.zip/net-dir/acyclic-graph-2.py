# Generates a random acyclic graph

import random
random.seed(1)

nodes = 2000
paths = nodes // 10

filename = "net-dir/acyclic" + str(nodes) + ".txt"


with open(filename, "w") as f:
    # Write pairs of nodes representing edges to the file
    for i in range(paths):
        # Choose a list of random nodes
        path_length = round(random.expovariate(1/(nodes/100)))
        if path_length <= 4:
            continue
        if path_length >= nodes:
            continue
        nodes_list = random.sample(range(1, nodes), path_length)
        # Sort the list
        nodes_list.sort()
        #print(nodes_list)
        # Write the path to the file
        for j in range(len(nodes_list)-1):
            f.write(str(nodes_list[j]) + " " + str(nodes_list[j+1]) + "\n")


        









