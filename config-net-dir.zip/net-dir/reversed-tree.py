# Generates a simple balanced (deep) tree

subtree_children = 5
nodes = 1000
filename = "net-dir/treegraph-r" + str(nodes) + ".txt"


with open(filename, "w") as f:
    # Write pairs of nodes representing edges to the file
    queue = [nodes]
    new_index = nodes - 1
    while len(queue) > 0:
        node = queue.pop(0)
        for i in range(subtree_children):
            f.write(str(node) + " " + str(new_index) +"\n")
            queue.append(new_index)
            new_index -= 1
            if new_index <= 1:
                break
        if new_index <= 1:
            break





