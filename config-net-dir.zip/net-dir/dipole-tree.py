# Generates two connected balanced trees, 
# one going in the positive direction and one going in the negative direction

subtree_children = 5
nodes = 10000
filename = "net-dir/dipole-graph" + str(nodes) + ".txt"


with open(filename, "w") as f:
    # Write pairs of nodes representing edges to the file
    queue1 = [1]
    new_index = 2
    nodes_per_side = nodes // 2

    # Outward facing tree
    while len(queue1) > 0:
        node = queue1.pop(0)

        for i in range(subtree_children):
            f.write(str(node) + " " + str(new_index) + "\n")
            queue1.append(new_index)
            new_index += 1  
            if new_index > nodes_per_side:
                break
        if new_index > nodes_per_side:
            break
    
    # Separate tree
    queue2 = [nodes]
    new_index = nodes - 1

    while len(queue2) > 0:
        node = queue2.pop(0)

        for i in range(subtree_children):
            f.write(str(new_index) + " " + str(node) + "\n")
            queue2.append(new_index)
            new_index -= 1
            if new_index <= nodes_per_side:
                break
        if new_index <= nodes_per_side:
            break

    
    # Connect the remaining nodes in the two queues
    while len(queue1) > 0 and len(queue2) > 0:
        node1 = queue1.pop(0)
        node2 = queue2.pop(0)
        f.write(str(node1) + " " + str(node2) + "\n")
    

