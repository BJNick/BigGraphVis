# Generates wide disconnected trees

subtree_children = 20
nodes = 1000
trees = 3
filename = "net-dir/treegraph-w-dis" + str(nodes) + ".txt"

with open(filename, "w") as f:
    # Write pairs of nodes representing edges to the file
    queue = [1]
    new_index = 2
    nodes_per_tree = nodes // trees
    for i in range(trees):
        while len(queue) > 0:
            node = queue.pop(0)
            for j in range(subtree_children):
                f.write(str(node) + " " + str(new_index) + "\n")
                queue.append(new_index)
                new_index += 1  
                if new_index > nodes_per_tree * (i+1):
                    break
            if new_index > nodes_per_tree * (i+1):
                break
        queue = [queue[-1] + 1]
        new_index = queue[0] + 1





