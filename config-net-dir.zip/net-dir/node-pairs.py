# Generate a list of disconnected edges

nodes = 1000
filename = "net-dir/pairs" + str(nodes) + ".txt"


with open(filename, "w") as f:
    # Write pairs of nodes representing edges to the file
    for i in range(1, nodes, 2):
        f.write(str(i) + " " + str(i + 1) + "\n")

