# Generates a deep binary tree

subtree_children = 2
nodes = 1000
filename = "net-dir/treegraph-b" + str(nodes) + ".txt"


with open(filename, "w") as f:
    # Write pairs of nodes representing edges to the file
    queue = [1]
    new_index = 2
    while len(queue) > 0:
        node = queue.pop(0)
        for i in range(subtree_children):
            f.write(str(node) + " " + str(new_index) + "\n")
            queue.append(new_index)
            new_index += 1  
            if new_index > nodes:
                break
        if new_index > nodes:
            break





