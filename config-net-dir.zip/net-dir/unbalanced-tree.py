# Generates an unbalanced tree with a random number of children per node

import random

random.seed(0)

subtree_min_children = 0
subtree_max_children = 5
nodes = 1000
filename = "net-dir/treegraph-unbal" + str(nodes) + ".txt"


with open(filename, "w") as f:
    # Write pairs of nodes representing edges to the file
    queue = [1]
    new_index = 2
    while len(queue) > 0:
        node = queue.pop(0)
        subtree_children = random.randint(subtree_min_children, subtree_max_children)
        for i in range(subtree_children):
            f.write(str(node) + " " + str(new_index) + "\n")
            queue.append(new_index)
            new_index += 1  
            if new_index > nodes:
                break
        if new_index > nodes:
            break





